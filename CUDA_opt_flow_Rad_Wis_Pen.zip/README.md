Projekt w ramach przedmiotu CUDA realizujący przepływ optyczny za pomocą dwóch algorytmów (Lucas-Kanade i Horn-Schunck)

Autorzy:
Antoni Radomiński-Lasek
Grzegorz Penter
Jakub Wisła

Przykładowa komenda do odpalenia projektu:

./src/main.out ./data/gray1.ppm ./data/gray2.ppm ./res/res.ppm LK
